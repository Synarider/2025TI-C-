import cv2
import numpy as np
from . import square_detector

def process(roi_image, contours, mm_per_pixel):
    """
    普通模式处理函数 (V3 - 重构版)。
    职责：
    1. 调用统一的 square_detector 模块来寻找所有正方形。
    2. 对检测结果应用成功条件（至少2个或1个旋转）。
    3. 在图像上绘制结果并打包返回。
    """
    if roi_image is None or mm_per_pixel <= 0:
        return None, {}

    display_image = roi_image.copy()

    # 1. 调用核心模块进行检测
    #    注意：新版的 find_squares 只需 roi_image 和 mm_per_pixel
    all_squares = square_detector.find_squares(roi_image, mm_per_pixel)

    # 2. 尺寸过滤
    valid_sized_squares = [s for s in all_squares if 60 <= s['size_mm'] <= 120]

    # 3. 成功条件判断
    is_successful = False
    if valid_sized_squares:
        found_two_or_more = len(valid_sized_squares) >= 2
        found_one_rotated = any(square_detector.is_rotated(s) for s in valid_sized_squares)
        is_successful = found_two_or_more or found_one_rotated

    # 4. 绘制所有在尺寸上有效的方块
    for square in valid_sized_squares:
        # 计算中心点用于标注
        m = cv2.moments(square['contour'])
        if m['m00'] > 0:
            center = (int(m['m10'] / m['m00']), int(m['m01'] / m['m00']))
            
            cv2.drawContours(display_image, [square['contour']], -1, (0, 255, 0), 2)
            cv2.putText(display_image, f"{square['size_mm']:.1f}mm", 
                        (center[0] - 25, center[1] + 5), 
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (50, 255, 255), 2)

    # 5. 准备返回结果
    results = {'total_shapes': len(valid_sized_squares), 'shapes': valid_sized_squares}
    if is_successful: 
        min_square = min(valid_sized_squares, key=lambda s: s['size_mm'])
        results['size_mm'] = f"{min_square['size_mm']:.2f}"
    
    return display_image, results
