import cv2
import numpy as np
from . import square_detector
from number.digit_recognizer import DigitRecognizer

# 在模块级别初始化一次，以避免重复加载模型
recognizer = DigitRecognizer()

def _get_closest_digit(roi_center, recognized_digits):
    """从识别到的数字列表中找到离ROI中心最近的一个。"""
    if not recognized_digits:
        return None

    closest_digit_info = None
    min_dist_sq = float('inf')
    roi_center_x, roi_center_y = roi_center

    for digit_info in recognized_digits:
        rect = digit_info['rect']
        digit_center_x = rect[0] + rect[2] / 2
        digit_center_y = rect[1] + rect[3] / 2
        
        dist_sq = (roi_center_x - digit_center_x)**2 + (roi_center_y - digit_center_y)**2
        
        if dist_sq < min_dist_sq:
            min_dist_sq = dist_sq
            closest_digit_info = digit_info
            
    return closest_digit_info

def process(roi_image, mm_per_pixel, target_digit=None):
    """
    高级模式处理函数 (V5 - 重构版)。
    1. 调用统一的 square_detector 模块寻找所有正方形。
    2. 对每个正方形，识别其内部最靠近中心的数字。
    3. 找出所有与目标数字匹配的正方形。
    4. 在图像上高亮所有匹配的正方形，并返回它们的尺寸。
    """
    if roi_image is None or roi_image.size == 0 or mm_per_pixel <= 0:
        return roi_image, {}

    display_image = roi_image.copy()

    # --- 步骤 1: 调用核心模块进行正方形检测 ---
    final_squares = square_detector.find_squares(roi_image, mm_per_pixel)
    
    # --- 步骤 2: 遍历正方形，识别数字并进行匹配 ---
    matches = [] # 存储所有匹配的结果
    
    for square in final_squares:
        x, y, w, h = cv2.boundingRect(square['contour'])
        square_roi_color = roi_image[y:y+h, x:x+w]
        
        # 在当前正方形的ROI内识别所有可能的数字
        recognized_digits_in_square = recognizer.find_and_recognize_digits(square_roi_color)
        
        if not recognized_digits_in_square:
            # 如果没识别出数字，画出未匹配的绿色框
            cv2.drawContours(display_image, [square['contour']], -1, (0, 255, 0), 2)
            continue

        # 找到离正方形中心最近的那个数字
        roi_center = (w / 2, h / 2)
        best_digit_info = _get_closest_digit(roi_center, recognized_digits_in_square)

        if best_digit_info is None:
             cv2.drawContours(display_image, [square['contour']], -1, (0, 255, 0), 2)
             continue

        recognized_digit = best_digit_info['digit']
        digit_rect = best_digit_info['rect']
        
        # 在 display_image 上标注识别出的数字
        abs_x, abs_y = x + digit_rect[0], y + digit_rect[1]
        cv2.putText(display_image, str(recognized_digit), (abs_x, abs_y - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 100, 0), 2)

        # 检查是否与目标数字匹配
        if target_digit is not None and recognized_digit == target_digit:
            # 匹配成功
            # 重新计算中心点，因为 square_detector 返回的可能没有
            m = cv2.moments(square['contour'])
            center = (int(m['m10']/m['m00']), int(m['m01']/m['m00'])) if m['m00'] != 0 else (x+w//2, y+h//2)
            
            matches.append({
                'size_mm': square['size_mm'],
                'contour': square['contour'],
                'center': center
            })
            # 用红色高亮匹配的正方形
            cv2.drawContours(display_image, [square['contour']], -1, (0, 0, 255), 3)
        else:
            # 未匹配
            cv2.drawContours(display_image, [square['contour']], -1, (0, 255, 0), 2)

    # --- 步骤 3: 准备最终结果 ---
    results = {
        'total_squares': len(final_squares),
        'found_target': len(matches) > 0,
        'matches': matches
    }

    # 在图像上为匹配项添加尺寸标注
    for match in matches:
        center = match['center']
        size_mm = match['size_mm']
        cv2.putText(display_image, f"{size_mm:.1f}mm", 
                    (int(center[0]) - 30, int(center[1]) + 30), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)

    return display_image, results
