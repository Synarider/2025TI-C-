import cv2
import numpy as np

# --- 配置参数 ---
CONFIG = {
    'min_area': 500, # 形状被识别所需的最小面积
}

def _classify_shape(contour):
    """
    一个精细的形状分类器，用于区分圆形、等边三角形和正方形。
    """
    shape = "unidentified"
    peri = cv2.arcLength(contour, True)
    approx = cv2.approxPolyDP(contour, 0.03 * peri, True) # 使用稍高的精度
    
    # --- 正方形检测 ---
    if len(approx) == 4:
        (x, y, w, h) = cv2.boundingRect(approx)
        ar = w / float(h)
        # 正方形的宽高比应接近1
        if 0.90 <= ar <= 1.10:
            shape = "square"
            return shape, approx

    # --- 等边三角形检测 ---
    elif len(approx) == 3:
        p1, p2, p3 = approx.reshape(3, 2)
        d1 = np.linalg.norm(p1 - p2)
        d2 = np.linalg.norm(p2 - p3)
        d3 = np.linalg.norm(p3 - p1)
        # 三条边的长度应大致相等
        if abs(d1 - d2) / d1 < 0.15 and abs(d1 - d3) / d1 < 0.15:
            shape = "triangle"
            return shape, approx
            
    # --- 圆形检测 ---
    else:
        area = cv2.contourArea(contour)
        if peri > 0:
            # 圆形度：一个完美的圆，其值为1
            circularity = 4 * np.pi * (area / (peri * peri))
            if 0.80 < circularity:
                shape = "circle"
                return shape, contour # 对于圆，绘制原始轮廓更平滑

    return "unidentified", None

def _get_shape_size_mm(shape, contour, mm_per_pixel):
    """根据形状类型计算其真实尺寸"""
    if shape == "square":
        _ ,_ , w, h = cv2.boundingRect(contour)
        size_px = (w + h) / 2.0
        return size_px * mm_per_pixel
    elif shape == "triangle":
        p1, p2, p3 = contour.reshape(3, 2)
        d1 = np.linalg.norm(p1 - p2)
        d2 = np.linalg.norm(p2 - p3)
        d3 = np.linalg.norm(p3 - p1)
        size_px = (d1 + d2 + d3) / 3.0
        return size_px * mm_per_pixel
    elif shape == "circle":
        ((_, _), radius) = cv2.minEnclosingCircle(contour)
        size_px = radius * 2
        return size_px * mm_per_pixel
    return 0

def process(roi_image, contours, mm_per_pixel):
    """
    基础模式处理函数。
    职责：对给定的ROI进行形状分类和测量。
    """
    if roi_image is None:
        placeholder = np.zeros((200, 200, 3), dtype=np.uint8)
        cv2.putText(placeholder, "No ROI Found", (20, 100), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (255, 255, 255), 1)
        return placeholder, {}

    display_image = roi_image.copy()

    if not contours or mm_per_pixel <= 0:
        return display_image, {}

    best_shape = "unidentified"
    best_size_mm = 0
    best_draw_contour = None

    sorted_contours = sorted(contours, key=cv2.contourArea, reverse=True)

    for contour in sorted_contours:
        shape, draw_contour = _classify_shape(contour)
        
        if shape != "unidentified":
            size_mm = _get_shape_size_mm(shape, draw_contour, mm_per_pixel)
            
            if 100 <= size_mm <= 160:
                best_shape = shape
                best_size_mm = size_mm
                best_draw_contour = draw_contour
                break

    results = {}
    if best_shape != "unidentified":
        results = {
            'shape': best_shape,
            'size_mm': f"{best_size_mm:.2f}",
        }
        label = f"{best_shape}: {best_size_mm:.1f}mm"
        cv2.drawContours(display_image, [best_draw_contour], -1, (0, 255, 0), 2)
        cv2.putText(display_image, label, (10, 30), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
    
    return display_image, results
