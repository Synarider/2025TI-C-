import cv2
import numpy as np

# --- 配置参数 ---
CONFIG = {
    'a4_aspect_ratio': 297/210,
    'aspect_ratio_tolerance': 0.1,
    'min_contour_area': 5000,
    'score_threshold': 0.4,
    'inner_min_contour_area': 500, 
    'morph_kernel_size': (3, 3), 
}
# --- 模块级状态 (光流+EMA) ---
_ema_alpha = 1.0
_tracked_points = None
_last_good_frame_gray = None
_frame_counter = 0
_redetection_interval = 1

# # --- 模块级状态 (光流+EMA) ---
# _ema_alpha = 0.2
# _tracked_points = None
# _last_good_frame_gray = None
# _frame_counter = 0
# _redetection_interval = 60

# --- 内部辅助函数 ---
def _order_points(pts):
    rect = np.zeros((4, 2), dtype="float32")
    s = pts.sum(axis=1); rect[0] = pts[np.argmin(s)]; rect[2] = pts[np.argmax(s)]
    diff = np.diff(pts, axis=1); rect[1] = pts[np.argmin(diff)]; rect[3] = pts[np.argmax(diff)]
    return rect

def _four_point_transform(image, pts):
    rect = _order_points(pts)
    (tl, tr, br, bl) = rect
    widthA = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2))
    widthB = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
    maxWidth = max(int(widthA), int(widthB))
    maxHeight = int(maxWidth * CONFIG['a4_aspect_ratio'])
    dst = np.array([[0, 0],[maxWidth - 1, 0],[maxWidth - 1, maxHeight - 1],[0, maxHeight - 1]], dtype="float32")
    M = cv2.getPerspectiveTransform(rect, dst)
    warped = cv2.warpPerspective(image, M, (maxWidth, maxHeight))
    return warped, maxHeight

def _score_contour(cnt):
    area = cv2.contourArea(cnt)
    if area < CONFIG['min_contour_area']: return -1, None
    rotated_rect = cv2.minAreaRect(cnt)
    w, h = rotated_rect[1]
    if w == 0 or h == 0: return -1, None
    rect_aspect_ratio = max(w, h) / min(w, h)
    aspect_score = np.exp(-(abs(rect_aspect_ratio - CONFIG['a4_aspect_ratio'])**2) / (2 * CONFIG['aspect_ratio_tolerance']**2))
    hull = cv2.convexHull(cnt)
    hull_area = cv2.contourArea(hull)
    if hull_area == 0: return -1, None
    solidity = float(area) / hull_area
    solidity_score = solidity if solidity > 0.9 else solidity**4
    peri = cv2.arcLength(cnt, True)
    approx = cv2.approxPolyDP(cnt, 0.02 * peri, True)
    poly_score = 1.0 if len(approx) == 4 else 0.2
    return (aspect_score * 0.5) + (solidity_score * 0.3) + (poly_score * 0.2), approx

def _extract_inner_roi_and_contours(warped_a4_paper):
    if warped_a4_paper is None: return None, None, None

    gray_full = cv2.cvtColor(warped_a4_paper, cv2.COLOR_BGR2GRAY)
    _, thresh_pre = cv2.threshold(gray_full, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    contours_pre, _ = cv2.findContours(thresh_pre, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours_pre: return None, None, None
    inner_contour = max(contours_pre, key=cv2.contourArea)
    x, y, w, h = cv2.boundingRect(inner_contour)
    if w < 50 or h < 50: return None, None, None
    inner_roi = warped_a4_paper[y:y+h, x:x+w]
    
    gray_roi = cv2.cvtColor(inner_roi, cv2.COLOR_BGR2GRAY)
    valid_mask = cv2.threshold(gray_roi, 1, 255, cv2.THRESH_BINARY)[1]
    binary = cv2.threshold(gray_roi, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1]
    binary = cv2.bitwise_and(binary, binary, mask=valid_mask)
    
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, CONFIG['morph_kernel_size'])
    binary = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel, iterations=2)
    binary = cv2.morphologyEx(binary, cv2.MORPH_OPEN, kernel, iterations=1)

    final_contours, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    candidate_contours = [cnt for cnt in final_contours if cv2.contourArea(cnt) > CONFIG['inner_min_contour_area']]
    
    # **关键修改**：返回四项内容
    return inner_roi, binary, candidate_contours

def extract_roi(frame):
    """
    本模块的主函数。返回四项内容：
    1. inner_roi: 用于显示的彩色内框图像。
    2. processed_binary: 处理后的二值图，用于调试。
    3. contours: 在内框中找到的高质量轮廓列表。
    4. mm_per_pixel: 像素到毫米的转换比例。
    """
    global _tracked_points, _last_good_frame_gray, _frame_counter
    if frame is None: return None, None, None, None
    
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    _frame_counter += 1
    
    # ... (光流跟踪逻辑不变) ...
    full_detection_needed = (_tracked_points is None) or (_frame_counter % _redetection_interval == 0)
    if full_detection_needed:
        edges = cv2.Canny(cv2.GaussianBlur(gray, (5, 5), 0), 50, 150)
        contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        best_score, best_approx = -1, None
        if contours:
            for cnt in sorted(contours, key=cv2.contourArea, reverse=True)[:5]:
                score, approx = _score_contour(cnt)
                if score > best_score: best_score, best_approx = score, approx
        if best_score >= CONFIG['score_threshold'] and best_approx is not None and len(best_approx) == 4:
            measured_points = best_approx.reshape(4, 2).astype(np.float32)
            if _tracked_points is None: _tracked_points = measured_points
            else: _tracked_points = _ema_alpha * measured_points + (1 - _ema_alpha) * _tracked_points
            _last_good_frame_gray = gray.copy()
    else:
        if _last_good_frame_gray is not None and _tracked_points is not None:
            new_raw_points, status, _ = cv2.calcOpticalFlowPyrLK(_last_good_frame_gray, gray, _tracked_points, None)
            if new_raw_points is not None and status.all() == 1:
                _tracked_points = _ema_alpha * new_raw_points + (1 - _ema_alpha) * _tracked_points
            _last_good_frame_gray = gray.copy()

    if _tracked_points is not None:
        warped_a4_paper, warped_height = _four_point_transform(frame, _tracked_points)
        
        # **关键修改**：接收新的返回值
        inner_roi, processed_binary, final_contours = _extract_inner_roi_and_contours(warped_a4_paper)
        
        if inner_roi is not None:
            mm_per_pixel = 297.0 / warped_height if warped_height > 0 else 0
            
            # **关键修改**：将所有需要的值全部返回
            return inner_roi, processed_binary, final_contours, mm_per_pixel
        else:
            # 如果未能成功提取内ROI，说明当前跟踪点可能已经漂移，强制重新检测
            _tracked_points = None

    return None, None, None, None
