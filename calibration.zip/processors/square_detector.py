import cv2
import numpy as np
from itertools import combinations
from sklearn.cluster import DBSCAN

# --- 几何与图像处理辅助函数 ---

def find_intersection(line1, line2):
    """计算两条线的交点"""
    x1, y1, x2, y2 = line1
    x3, y3, x4, y4 = line2
    a1, b1 = y2 - y1, x1 - x2
    c1 = a1 * x1 + b1 * y1
    a2, b2 = y4 - y3, x3 - x4
    c2 = a2 * x3 + b2 * y3
    determinant = a1 * b2 - a2 * b1
    if determinant == 0: return None
    x = (b2 * c1 - b1 * c2) / determinant
    y = (a1 * c2 - a2 * c1) / determinant
    return int(x), int(y)

def get_line_angle_rho(line):
    """计算线的角度 (0-pi) 和到原点的垂直距离"""
    x1, y1, x2, y2 = line
    angle = np.arctan2(y2 - y1, x2 - x1)
    if angle < 0: angle += np.pi
    A, B = y2 - y1, x1 - x2
    C = -A * x1 - B * y1
    rho = C / (np.sqrt(A**2 + B**2) + 1e-6)
    return angle, rho

def check_coverage(contour, edge_mask):
    """验证轮廓的边缘覆盖度"""
    if contour is None or len(contour) < 4: return 0
    perimeter = cv2.arcLength(contour, True)
    if perimeter < 1: return 0
    boundary_mask = np.zeros_like(edge_mask)
    cv2.drawContours(boundary_mask, [contour], 0, 255, 1)
    overlap = cv2.bitwise_and(edge_mask, boundary_mask)
    return np.sum(overlap) / (255.0 * perimeter + 1e-6)

def check_darkness(contour, gray_image):
    """验证轮廓内部是否为黑色"""
    mask = np.zeros_like(gray_image)
    cv2.drawContours(mask, [contour], -1, 255, -1)
    mean_val = cv2.mean(gray_image, mask=mask)[0]
    return mean_val < 80

def calculate_iou(box1, box2):
    """计算两个边界框的交并比 (Intersection over Union)"""
    x1, y1, w1, h1 = box1
    x2, y2, w2, h2 = box2
    x_left, y_top = max(x1, x2), max(y1, y2)
    x_right, y_bottom = min(x1 + w1, x2 + w2), min(y1 + h1, y2 + h2)
    if x_right < x_left or y_bottom < y_top: return 0.0
    intersection_area = (x_right - x_left) * (y_bottom - y_top)
    box1_area, box2_area = w1 * h1, w2 * h2
    union_area = float(box1_area + box2_area - intersection_area)
    return intersection_area / union_area if union_area > 0 else 0.0

def is_rotated(square):
    """根据外接矩形面积与轮廓面积的比值判断是否旋转。"""
    contour_area = cv2.contourArea(square['contour'])
    if contour_area < 1: return False
    x, y, w, h = cv2.boundingRect(square['contour'])
    return (w * h) / contour_area > 1.2

# --- 核心检测函数 ---

def find_squares(roi_image, mm_per_pixel):
    """
    核心正方形检测函数。
    接收ROI图像和比例尺，返回所有检测到的、经过过滤的正方形列表。
    """
    if roi_image is None or roi_image.size == 0 or mm_per_pixel <= 0:
        return []

    gray = cv2.cvtColor(roi_image, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    
    v = np.median(blurred)
    sigma = 0.33
    lower_thresh = int(max(0, (1.0 - sigma) * v))
    upper_thresh = int(min(255, (1.0 + sigma) * v))
    edges = cv2.Canny(blurred, lower_thresh, upper_thresh, apertureSize=3)

    all_contours, hierarchy = cv2.findContours(edges, cv2.RETR_CCOMP, cv2.CHAIN_APPROX_SIMPLE)
    
    valid_contours = []
    if hierarchy is not None:
        roi_h, roi_w = roi_image.shape[:2]
        for i, cnt in enumerate(all_contours):
            if hierarchy[0][i][3] != -1: continue
            area = cv2.contourArea(cnt)
            if not (100 < area < (roi_h * roi_w * 0.9)): continue
            x, y, w, h = cv2.boundingRect(cnt)
            if x <= 5 or y <= 5 or (x + w) >= (roi_w - 5) or (y + h) >= (roi_h - 5): continue
            valid_contours.append(cnt)

    clean_edges_mask = np.zeros_like(edges)
    cv2.drawContours(clean_edges_mask, valid_contours, -1, 255, 1)

    lines = cv2.HoughLinesP(clean_edges_mask, 1, np.pi / 180, threshold=10, minLineLength=15, maxLineGap=15)
    if lines is None: return []

    all_lines_with_props = [{'line': line[0], 'angle': get_line_angle_rho(line[0])[0], 'rho': get_line_angle_rho(line[0])[1]} for line in lines]
    if not all_lines_with_props: return []

    angles = np.array([[l['angle']] for l in all_lines_with_props])
    angle_db = DBSCAN(eps=np.deg2rad(8), min_samples=2).fit(angles)
    
    line_groups = {}
    unique_labels = set(angle_db.labels_)
    for label in unique_labels:
        if label == -1: continue
        indices = np.where(angle_db.labels_ == label)[0]
        group_lines = [all_lines_with_props[i] for i in indices]
        rhos = np.array([[l['rho']] for l in group_lines])
        rho_db = DBSCAN(eps=20, min_samples=1).fit(rhos)
        clustered_by_rho = []
        for rho_label in set(rho_db.labels_):
            if rho_label == -1: continue
            rho_indices = np.where(rho_db.labels_ == rho_label)[0]
            best_line = max([group_lines[i]['line'] for i in rho_indices], key=lambda l: np.linalg.norm((l[0]-l[2], l[1]-l[3])))
            clustered_by_rho.append(best_line)
        if clustered_by_rho:
            line_groups[label] = {'lines': clustered_by_rho, 'angle': np.mean([l['angle'] for l in group_lines])}

    detected_squares = []
    group_keys = list(line_groups.keys())
    for i in range(len(group_keys)):
        for j in range(i + 1, len(group_keys)):
            key1, key2 = group_keys[i], group_keys[j]
            angle_diff = abs(line_groups[key1]['angle'] - line_groups[key2]['angle'])
            if abs(angle_diff - np.pi/2) < np.deg2rad(20):
                lines1, lines2 = line_groups[key1]['lines'], line_groups[key2]['lines']
                if len(lines1) < 2 or len(lines2) < 2: continue
                for h1, h2 in combinations(lines1, 2):
                    for v1, v2 in combinations(lines2, 2):
                        pts = [find_intersection(h1, v1), find_intersection(h1, v2), find_intersection(h2, v2), find_intersection(h2, v1)]
                        if None in pts: continue
                        center = np.mean(pts, axis=0)
                        sorted_pts = sorted(pts, key=lambda p: np.arctan2(p[1]-center[1], p[0]-center[0]))
                        contour = np.array(sorted_pts, dtype=np.int32).reshape((-1, 1, 2))
                        w, h = np.linalg.norm(np.array(sorted_pts[0])-sorted_pts[1]), np.linalg.norm(np.array(sorted_pts[1])-sorted_pts[2])
                        if min(w,h) > 0 and 0.80 < max(w,h)/min(w,h) < 1.20 and check_coverage(contour, clean_edges_mask) > 0.4 and check_darkness(contour, gray):
                            detected_squares.append({'size_mm': ((w+h)/2)*mm_per_pixel, 'contour': contour})

    # 智能去重 (Smart NMS)
    final_squares = []
    if detected_squares:
        detected_squares.sort(key=lambda s: cv2.contourArea(s['contour']), reverse=True)
        suppressed = [False] * len(detected_squares)
        for i in range(len(detected_squares)):
            if suppressed[i]: continue
            
            final_squares.append(detected_squares[i])
            contour1 = detected_squares[i]['contour']
            box1 = cv2.boundingRect(contour1)
            is_rotated1 = is_rotated(detected_squares[i])

            for j in range(i + 1, len(detected_squares)):
                if suppressed[j]: continue
                
                contour2 = detected_squares[j]['contour']
                box2 = cv2.boundingRect(contour2)
                iou = calculate_iou(box1, box2)
                is_rotated2 = is_rotated(detected_squares[j])
                
                iou_threshold = 0.25 if is_rotated1 and is_rotated2 else 0.4
                
                is_contained = False
                m2 = cv2.moments(contour2)
                if m2['m00'] > 0:
                    c2_x, c2_y = int(m2['m10'] / m2['m00']), int(m2['m01'] / m2['m00'])
                    if cv2.pointPolygonTest(contour1, (c2_x, c2_y), False) > 0:
                        is_contained = True
                        
                if iou > iou_threshold or is_contained:
                    suppressed[j] = True
    
    return final_squares
