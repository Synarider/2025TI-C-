import cv2
import numpy as np

class DigitRecognizer:
    def __init__(self, model_path='number/digit_knn_model_augmented_aggressive.yml'):
        """
        初始化数字识别器，加载预训练的KNN模型。
        """
        try:
            self.knn = cv2.ml.KNearest_load(model_path)
            self.model_loaded = True
            print(f"✅ KNN model for Canny edges loaded successfully from {model_path}")
        except cv2.error as e:
            print(f"❌ Error loading KNN model from {model_path}: {e}")
            self.knn = None
            self.model_loaded = False

    def _predict_digit(self, edge_roi_for_prediction):
        """
        使用KNN模型识别单个数字的 *Canny边缘图* ROI。
        """
        if self.knn is None: return None
        
        border_size = 4
        roi_padded = cv2.copyMakeBorder(edge_roi_for_prediction, border_size, border_size, border_size, border_size, cv2.BORDER_CONSTANT, value=0)
        resized = cv2.resize(roi_padded, (32, 32), interpolation=cv2.INTER_AREA)
        sample = resized.flatten().astype(np.float32).reshape(1, -1)
        
        _, result, _, _ = self.knn.findNearest(sample, k=5)
        return int(result[0][0]) if result is not None else None

    def find_and_recognize_digits(self, roi_image):
        """
        在给定的ROI图像中寻找并识别所有数字。
        V5: 增加了对ROI大小的健全性检查，以防止将空图像传递给KNN模型，从而修复断言失败的错误。
        """
        if not self.model_loaded or roi_image is None:
            return []

        recognized_digits = []
        try:
            gray = cv2.cvtColor(roi_image, cv2.COLOR_BGR2GRAY)
            blurred = cv2.GaussianBlur(gray, (5, 5), 0)
            canny_map = cv2.Canny(blurred, 50, 150)

            contours, _ = cv2.findContours(canny_map.copy(), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

            for cnt in contours:
                x, y, w, h = cv2.boundingRect(cnt)

                if not (5 < w < 40 and 10 < h < 50 and h / float(w) > 1.1):
                    continue

                digit_roi_edges = canny_map[y:y+h, x:x+w]
                
                # --- 核心修复：健全性检查 ---
                # 在将ROI发送到预测函数之前，确保它不是空的。
                if digit_roi_edges.size == 0:
                    continue # 如果ROI为空，则跳过此轮廓

                predicted_digit = self._predict_digit(digit_roi_edges)

                if predicted_digit is not None:
                    recognized_digits.append({'digit': predicted_digit, 'rect': (x, y, w, h)})
        
        except Exception as e:
            # 打印更详细的错误信息
            print(f"❌ An error occurred during number recognition: {e}")

        return recognized_digits
