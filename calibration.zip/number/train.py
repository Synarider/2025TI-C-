import cv2
import numpy as np
import os

# ----------------------------
# 一：生成数据集（含更丰富的数据增强）
# ----------------------------

output_dir = "digit_edge_dataset_aug2"
os.makedirs(output_dir, exist_ok=True)

fonts = {
    'SIMPLEX'       : cv2.FONT_HERSHEY_SIMPLEX,
    'PLAIN'         : cv2.FONT_HERSHEY_PLAIN,
    'DUPLEX'        : cv2.FONT_HERSHEY_DUPLEX,
    'COMPLEX'       : cv2.FONT_HERSHEY_COMPLEX,
    'TRIPLEX'       : cv2.FONT_HERSHEY_TRIPLEX,
    'COMPLEX_SMALL' : cv2.FONT_HERSHEY_COMPLEX_SMALL,
    'SCRIPT_SIMPLEX': cv2.FONT_HERSHEY_SCRIPT_SIMPLEX,
    'SCRIPT_COMPLEX': cv2.FONT_HERSHEY_SCRIPT_COMPLEX,
}

digits = [str(i) for i in range(10)]

canvas_size   = 100
scale         = 3
thickness     = 3
canny_l, canny_h = 50, 150
resize_sz     = 32
aug_per_sample= 10  # 增加每个基准样本的增强次数

features = []
labels   = []

def random_brightness_contrast(img):
    """随机改变亮度和对比度"""
    alpha = np.random.uniform(0.7, 1.3)  # contrast
    beta  = np.random.uniform(-30, 30)   # brightness
    return np.clip(alpha * img + beta, 0, 255).astype(np.uint8)

def random_noise(img):
    """添加椒盐噪声"""
    out = img.copy()
    prob = np.random.uniform(0.0, 0.02)
    # 椒盐噪声
    mask = np.random.choice([0,1,2], size=img.shape, p=[1-prob, prob/2, prob/2])
    out[mask==1] = 255
    out[mask==2] = 0
    return out

def random_perspective(img):
    """随机透视变换"""
    h, w = img.shape
    margin = w * 0.1
    pts1 = np.float32([[0,0],[w,0],[0,h],[w,h]])
    pts2 = pts1 + np.random.uniform(-margin, margin, pts1.shape).astype(np.float32)
    M = cv2.getPerspectiveTransform(pts1, pts2)
    return cv2.warpPerspective(img, M, (w,h), borderValue=0)

def augment_and_features(base_img):
    feats = []
    for _ in range(aug_per_sample):
        aug = base_img.copy()
        # 1. 随机仿射：旋转、缩放、平移
        angle = np.random.uniform(-20, 20)
        scale_factor = np.random.uniform(0.8, 1.2)
        M = cv2.getRotationMatrix2D((canvas_size/2, canvas_size/2), angle, scale_factor)
        aug = cv2.warpAffine(aug, M, (canvas_size, canvas_size), borderValue=0)
        tx, ty = np.random.randint(-10,11), np.random.randint(-10,11)
        aug = cv2.warpAffine(aug, np.float32([[1,0,tx],[0,1,ty]]),
                             (canvas_size, canvas_size), borderValue=0)

        # 2. 随机亮度/对比度
        if np.random.rand() < 0.5:
            aug = random_brightness_contrast(aug)

        # 3. 随机透视
        if np.random.rand() < 0.3:
            aug = random_perspective(aug)

        # 4. 随机模糊
        if np.random.rand() < 0.3:
            ksize = np.random.choice([3,5])
            aug = cv2.GaussianBlur(aug, (ksize,ksize), 0)

        # 5. 随机噪声
        if np.random.rand() < 0.3:
            aug = random_noise(aug)

        # 6. 随机形态学：开/闭/腐蚀/膨胀
        r = np.random.rand()
        k = cv2.getStructuringElement(cv2.MORPH_RECT, (3,3))
        if r < 0.25:
            aug = cv2.morphologyEx(aug, cv2.MORPH_OPEN, k)
        elif r < 0.5:
            aug = cv2.morphologyEx(aug, cv2.MORPH_CLOSE, k)
        elif r < 0.75:
            aug = cv2.erode(aug, k, iterations=1)
        else:
            aug = cv2.dilate(aug, k, iterations=1)

        # 7. Canny 边缘
        edges = cv2.Canny(aug, canny_l, canny_h)

        # 8. 缩放 & 扁平化
        e32 = cv2.resize(edges, (resize_sz, resize_sz), interpolation=cv2.INTER_AREA)
        feats.append(e32.flatten().astype(np.float32))
    return feats

for font_name, font in fonts.items():
    font_dir = os.path.join(output_dir, font_name)
    os.makedirs(font_dir, exist_ok=True)
    for d in digits:
        img = np.zeros((canvas_size, canvas_size), dtype=np.uint8)
        (tw, th), _ = cv2.getTextSize(d, font, scale, thickness)
        x = (canvas_size - tw)//2
        y = (canvas_size + th)//2
        cv2.putText(img, d, (x, y), font, scale, 255, thickness, cv2.LINE_AA)

        # 原始边缘
        edges = cv2.Canny(img, canny_l, canny_h)
        cv2.imwrite(os.path.join(font_dir, f"{d}.png"), edges)
        e32 = cv2.resize(edges, (resize_sz, resize_sz), interpolation=cv2.INTER_AREA)
        features.append(e32.flatten().astype(np.float32))
        labels.append(int(d))

        # 增强样本
        aug_feats = augment_and_features(img)
        features.extend(aug_feats)
        labels.extend([int(d)] * len(aug_feats))

features = np.array(features, dtype=np.float32)
labels   = np.array(labels,   dtype=np.int32)
print(f"样本数：{features.shape[0]}, 维度：{features.shape[1]}")

# ----------------------------
# 二：训练 KNN
# ----------------------------
knn = cv2.ml.KNearest_create()
knn.setDefaultK(3)
knn.train(features, cv2.ml.ROW_SAMPLE, labels)
knn.save("digit_knn_model_augmented_aggressive.yml")
print("训练并保存为 digit_knn_model_augmented_aggressive.yml")

# ----------------------------
# 三：预测示例
# ----------------------------
def predict_digit(edge_img):
    e32 = cv2.resize(edge_img, (resize_sz, resize_sz), interpolation=cv2.INTER_AREA)
    sample = e32.flatten().reshape(1, -1)
    _, res, _, _ = knn.findNearest(sample.astype(np.float32), k=3)
    return int(res[0][0])

# 测试
test_img = cv2.imread(os.path.join(output_dir, 'SIMPLEX', '3.png'), cv2.IMREAD_GRAYSCALE)
print("测试预测 SIMPLEX '3' →", predict_digit(test_img))
