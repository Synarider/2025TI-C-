#coding=utf-8
import cv2
import numpy as np
import mvsdk
from threading import Event

class SimpleCamera:
    """简化的工业相机封装类 - 专为图像处理设计"""
    
    def __init__(self, camera_index=0, exposure_time=30):
        self.hCamera = None
        self.pFrameBuffer = None
        self.latest_frame = None
        self.is_running = False
        self.frame_ready = Event()
        self.width = 0
        self.height = 0
        self._init_camera(camera_index, exposure_time)

    def _init_camera(self, camera_index, exposure_time):
        """初始化相机（隐藏复杂的配置过程）"""
        try:
            # 枚举相机
            DevList = mvsdk.CameraEnumerateDevice()
            if len(DevList) == 0:
                raise Exception("未找到相机设备")
            
            # 选择相机
            DevInfo = DevList[camera_index] if camera_index < len(DevList) else DevList[0]
            print(f"已连接相机: {DevInfo.GetFriendlyName()}")
            
            # 打开相机
            self.hCamera = mvsdk.CameraInit(DevInfo, -1, -1)
            
            # 获取相机能力并显示关键信息
            cap = mvsdk.CameraGetCapability(self.hCamera)
            self.width = cap.sResolutionRange.iWidthMax
            self.height = cap.sResolutionRange.iHeightMax
            print(f"相机分辨率: {self.width} x {self.height}")
            
            # 配置相机参数
            mvsdk.CameraSetIspOutFormat(self.hCamera, mvsdk.CAMERA_MEDIA_TYPE_BGR8)
            mvsdk.CameraSetTriggerMode(self.hCamera, 0)  # 连续模式
            mvsdk.CameraSetAeState(self.hCamera, 0)      # 手动曝光
            mvsdk.CameraSetExposureTime(self.hCamera, exposure_time * 1000)
            mvsdk.CameraSetSharpness(self.hCamera, 0)
            mvsdk.CameraSetInverse(self.hCamera, False)

            # 分配内存
            FrameBufferSize = self.width * self.height * 3
            self.pFrameBuffer = mvsdk.CameraAlignMalloc(FrameBufferSize, 16)
            
        except Exception as e:
            print(f"相机初始化失败: {e}")
            raise

    def start_stream(self):
        """开始异步图像流"""
        if self.is_running or self.hCamera is None:
            return
        # 开始采集
        mvsdk.CameraPlay(self.hCamera)
        self.is_running = True
        mvsdk.CameraSetCallbackFunction(self.hCamera, self._frame_callback, 0)
        print("图像流已开始...")

    def stop_stream(self):
        """停止图像流"""
        self.is_running = False
    
    def get_latest_frame(self, wait=True, timeout=1.0):
        """获取最新帧（异步模式）"""
        if wait:
            ready = self.frame_ready.wait(timeout)
            if not ready:
                return None
        # self.frame_ready.clear() # 在回调中处理，避免竞态条件
        return self.latest_frame.copy() if self.latest_frame is not None else None

    @mvsdk.method(mvsdk.CAMERA_SNAP_PROC)
    def _frame_callback(self, hCamera, pRawData, pFrameHead, pContext):
        """图像回调函数"""
        if not self.is_running:
            return
        try:
            self.frame_ready.clear()
            FrameHead = pFrameHead[0]
            mvsdk.CameraImageProcess(hCamera, pRawData, self.pFrameBuffer, FrameHead)
            frame_data = (mvsdk.c_ubyte * FrameHead.uBytes).from_address(self.pFrameBuffer)
            frame = np.frombuffer(frame_data, dtype=np.uint8)
            self.latest_frame = frame.reshape((FrameHead.iHeight, FrameHead.iWidth, 3))
            self.frame_ready.set()
        finally:
            mvsdk.CameraReleaseImageBuffer(hCamera, pRawData)

    def close(self):
        """关闭相机"""
        if self.hCamera:
            self.stop_stream()
            mvsdk.CameraUnInit(self.hCamera)
            if self.pFrameBuffer:
                mvsdk.CameraAlignFree(self.pFrameBuffer)
            self.hCamera = None
            self.pFrameBuffer = None
            print("相机已关闭")
