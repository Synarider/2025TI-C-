import pandas as pd
import numpy as np
import os

class CalibrationManager:
    """
    一个管理相机标定数据的类。
    它负责加载数据，拟合模型，并提供计算距离和像素比例尺的功能。
    """
    def __init__(self, data_path='calibration/calibration_data.csv'):
        """
        初始化标定管理器。
        - 加载指定的CSV标定数据。
        - 使用数据对“像素长度 -> 实际距离”的关系进行“反比+截距”模型拟合。
        """
        self.model = None
        self._fit_model(data_path)

    def _fit_model(self, data_path):
        """
        加载数据并拟合一个“反比+截距”模型 (y = k/x + c)。
        这个模型在物理上更符合相机成像原理。
        """
        if not os.path.exists(data_path):
            print(f"错误：找不到标定文件 at '{data_path}'")
            return

        try:
            df = pd.read_csv(data_path)

            # --- 模型修改 ---
            # 为了拟合 y = k/x + c 模型，我们将其转换为线性关系。
            # 令 x' = 1/x (其中x是像素长度)，则模型变为 y = k*x' + c，这是一个标准的线性方程。
            # 因此，我们对 (1/pixel_lengths) 和 (distances) 进行1阶多项式（线性）拟合。
            pixel_lengths = df['外框像素长度']
            distances = df['目标体距离']

            # 计算像素长度的倒数
            inv_pixel_lengths = 1 / pixel_lengths
            
            # 使用numpy进行1阶多项式拟合 (y = k*x' + c)
            # 返回的 model_coeffs 是多项式的系数 [k, c]
            model_coeffs = np.polyfit(inv_pixel_lengths, distances, 1)
            
            # 创建一个可调用的多项式函数对象，该对象代表 y = k*x' + c
            self.model = np.poly1d(model_coeffs)
            
            print("距离标定模型已成功拟合 (反比+截距模型)。")
            print(f"模型系数 (k, c): {model_coeffs}")

        except Exception as e:
            print(f"拟合标定模型时发生错误: {e}")

    def get_distance(self, outer_frame_pixel_length):
        """
        根据A4纸外框的像素长度，使用 y = k/x + c 模型预测相机到目标的实际距离。
        """
        if self.model is None:
            print("警告：距离标定模型尚未初始化。")
            return -1.0
        
        # 防止除以零的错误
        if outer_frame_pixel_length <= 0:
            return -1.0
        
        # **模型应用修改**
        # 为了使用 y = k*x' + c 模型，我们需要传入 x' = 1/x
        inv_pixel_length = 1 / outer_frame_pixel_length
        predicted_distance = self.model(inv_pixel_length)
        
        return predicted_distance

    @staticmethod
    def get_mm_per_pixel(outer_frame_pixel_length):
        """
        根据A4纸外框的像素长度，计算当前图像的“毫米/像素”比例尺。
        """
        A4_LONG_SIDE_MM = 297.0
        
        if outer_frame_pixel_length is None or outer_frame_pixel_length <= 0:
            return 0.0
            
        return A4_LONG_SIDE_MM / outer_frame_pixel_length
