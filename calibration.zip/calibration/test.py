import numpy as np
import pandas as pd

# 1. 准备数据
data = {
    'pixel_len': [628.0, 596.0, 557.0, 530.0, 507.0, 482.0, 465.0, 446.0, 425.0, 409.0,
                  395.0, 385.0, 375.0, 366.1, 356.0, 349.0, 341.0, 335.0, 328.0, 322.0,
                  316.0, 309.0, 301.0, 294.0, 288.1, 279.0, 272.0, 264.0, 258.0, 252.0],
    'dist':      [845.0, 889.0, 953.0, 1005.0, 1052.0, 1106.0, 1148.0, 1182.0, 1258.0, 1307.0,
                  1355.0, 1390.0, 1431.0, 1469.0, 1506.0, 1538.0, 1570.0, 1601.0, 1635.0, 1670.0,
                  1699.0, 1740.0, 1784.0, 1828.0, 1869.0, 1921.0, 1977.0, 2035.0, 2087.0, 2129.0]
}
df = pd.DataFrame(data)

# 2. 构建设计矩阵 X 和目标 y
x = (1.0 / df['pixel_len']).values.reshape(-1, 1)  # shape (30,1)
X = np.hstack([x, np.ones_like(x)])               # shape (30,2)
y = df['dist'].values                             # shape (30,)

# 3. 最小二乘求解 [C, k]
coef, *_ = np.linalg.lstsq(X, y, rcond=None)
C, k = coef
print(f"拟合结果: C = {C:.2f},  k = {k:.2f}")

# 4. 预测与误差
df['dist_pred'] = C / df['pixel_len'] + k
df['err_dist']  = df['dist_pred'] - df['dist']
mae = df['err_dist'].abs().mean()
print(f"平均绝对误差 MAE = {mae:.2f} 单位距离")

# 5. 展示前 5 条结果
print(df[['pixel_len','dist','dist_pred','err_dist']].head())
