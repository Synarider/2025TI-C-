import sys
import cv2
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QPushButton,
    QHBoxLayout, QVBoxLayout, QGridLayout, QSizePolicy, QMessageBox
)
from PyQt5.QtCore import QTimer, Qt
from PyQt5.QtGui import QImage, QPixmap
from camera_handler import SimpleCamera

from processors import roi_handler, basic_processor, normal_processor, advanced_processor
from calibration.calibration_manager import CalibrationManager

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("目标物测量界面")
        
        self.camera = SimpleCamera()
        self.calibration_manager = CalibrationManager()
        
        # --- 状态变量 ---
        self.current_frame = None
        self.target_digit = None
        self.is_detecting = False       # 是否处于持续检测状态
        self.active_processor_info = {} # 存储当前激活的处理器信息
        
        self.processors = {
            "基础": basic_processor,
            "普通": normal_processor,
            "发挥": advanced_processor,
        }
        
        self.init_ui()
        self.camera.start_stream()
        
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(30) # ~33 FPS

    def init_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        top_layout = QHBoxLayout()
        main_layout.addLayout(top_layout)
        self.video_label = QLabel()
        self.video_label.setFixedSize(640, 480)
        self.video_label.setStyleSheet("background-color: black;")
        top_layout.addWidget(self.video_label)
        mid_layout = QVBoxLayout()
        self.roi_label = QLabel("ROI Display")
        self.roi_label.setAlignment(Qt.AlignCenter)
        self.roi_label.setFixedSize(200, 200)
        self.roi_label.setStyleSheet("background-color: #ddd; color: #555;")
        mid_layout.addWidget(self.roi_label, alignment=Qt.AlignHCenter)
        for text in self.processors.keys():
            btn = QPushButton(text)
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
            btn.clicked.connect(self.on_process_button_clicked)
            mid_layout.addWidget(btn)
        top_layout.addLayout(mid_layout)
        right_layout = QVBoxLayout()
        self.d_label = QLabel("距离 D: N/A")
        self.x_label = QLabel("尺寸 X: N/A")
        self.target_label = QLabel("目标数字: 未选择")
        right_layout.addWidget(self.d_label)
        right_layout.addWidget(self.x_label)
        right_layout.addWidget(self.target_label)
        
        grid = QGridLayout()
        keys = ["1","2","3","4","5","6","7","8","9","","0",""]
        positions = [(i, j) for i in range(4) for j in range(3)]
        for pos, key in zip(positions, keys):
            if key:
                btn = QPushButton(key)
                btn.setFixedSize(50, 50)
                btn.clicked.connect(lambda checked, k=key: self.on_number_clicked(k))
                grid.addWidget(btn, *pos)
        right_layout.addLayout(grid)
        top_layout.addLayout(right_layout)
        bottom_layout = QHBoxLayout()
        self.current_label = QLabel("电流: 0.00 A")
        self.power_label = QLabel("功耗P: 0.00 W")
        self.max_power_label = QLabel("最大功率: 0.00 W")
        bottom_layout.addWidget(self.current_label)
        bottom_layout.addWidget(self.power_label)
        bottom_layout.addWidget(self.max_power_label)
        main_layout.addLayout(bottom_layout)

    def on_process_button_clicked(self):
        """当处理按钮被点击时，启动持续检测状态。"""
        sender = self.sender()
        if not sender: return

        button_text = sender.text()
        
        if button_text == "发挥" and self.target_digit is None:
            QMessageBox.warning(self, "提示", "请先从右侧数字键盘选择一个目标数字！")
            return
        
        # 设置激活的处理器信息
        self.active_processor_info = {
            'processor': self.processors.get(button_text),
            'text': button_text
        }
        
        # 进入持续检测状态，并在界面上提示用户
        self.is_detecting = True
        self.d_label.setText("距离 D: Searching...")
        self.x_label.setText("尺寸 X: Searching...")
        self.roi_label.setText("Detecting...")

    def update_frame(self):
        """定时器调用的主函数：刷新画面并执行检测（如果需要）。"""
        frame = self.camera.get_latest_frame(wait=True, timeout=0.1)
        if frame is None: return
        self.current_frame = cv2.flip(frame, 1)

        # 1. 更新主视频画面
        rgb = cv2.cvtColor(self.current_frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        bytes_line = ch * w
        img = QImage(rgb.data, w, h, bytes_line, QImage.Format_RGB888)
        pix = QPixmap.fromImage(img).scaled(self.video_label.size(), Qt.KeepAspectRatio)
        self.video_label.setPixmap(pix)

        # 2. 如果处于持续检测状态，则对当前帧进行处理
        if self.is_detecting:
            self.run_detection_cycle()

    def run_detection_cycle(self):
        """执行一次完整的检测流程。"""
        if not self.active_processor_info:
            return

        processor = self.active_processor_info['processor']
        button_text = self.active_processor_info['text']

        # 1. 提取ROI
        roi_color, _, contours, mm_per_pixel = roi_handler.extract_roi(self.current_frame)

        if roi_color is None or mm_per_pixel <= 0:
            return # ROI提取失败，等待下一帧

        # 2. 计算距离 (无论如何都计算)
        distance = self.calibration_manager.get_distance(297.0 / mm_per_pixel)

        # 3. 调用相应的处理器
        final_image, results = None, {}
        
        if button_text == "发挥":
            final_image, results = processor.process(roi_color, mm_per_pixel, target_digit=self.target_digit)
            # 对于发挥模式，只要找到目标就认为成功
            is_valid_result = results.get('found_target', False)
        else: # 基础和普通模式
            final_image, results = processor.process(roi_color, contours, mm_per_pixel)
            # 对于基础/普通模式，只有找到尺寸才算成功
            is_valid_result = 'size_mm' in results

        # 4. 如果找到有效结果，则更新UI并停止检测
        if is_valid_result:
            self.is_detecting = False # 停止持续检测
            
            # 更新UI
            self.d_label.setText(f"距离 D: {distance:.2f} mm")
            self.update_roi_display(final_image)

            if button_text == "发挥":
                if results.get('matches'):
                    sizes_str = ", ".join([f"{m['size_mm']:.2f}" for m in results['matches']])
                    self.x_label.setText(f"目标 {self.target_digit} 尺寸: {sizes_str} mm")
                else:
                    self.x_label.setText(f"目标 {self.target_digit}: 未找到")
            else:
                self.x_label.setText(f"尺寸 X: {float(results['size_mm']):.2f} mm")
        
        # 如果结果无效，则什么都不做，UI保持"Searching..."，等待下一帧自动重试

    def update_roi_display(self, image_to_show):
        if image_to_show is None:
            self.roi_label.setText("处理失败")
            return
        if len(image_to_show.shape) == 2:
            image_to_show = cv2.cvtColor(image_to_show, cv2.COLOR_GRAY2BGR)
        rgb_roi = cv2.cvtColor(image_to_show, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_roi.shape
        bytes_line = ch * w
        img = QImage(rgb_roi.data, w, h, bytes_line, QImage.Format_RGB888)
        pix = QPixmap.fromImage(img).scaled(self.roi_label.size(), Qt.KeepAspectRatio)
        self.roi_label.setPixmap(pix)
        
    def on_number_clicked(self, num_str):
        self.target_digit = int(num_str)
        self.target_label.setText(f"目标数字: {self.target_digit}")
        # 如果正在检测中，点击数字可以立即更新目标，无需重启检测
        print(f"已选择目标数字: {self.target_digit}")

    def closeEvent(self, event):
        self.timer.stop()
        self.camera.close()
        cv2.destroyAllWindows()
        super().closeEvent(event)

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
